#!/bin/bash
cp bin/example /usr/bin/
