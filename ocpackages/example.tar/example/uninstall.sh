#!/bin/bash
rm /usr/bin/example
