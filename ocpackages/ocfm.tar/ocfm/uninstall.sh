#!/bin/bash
#This script will attempt to remove all traces of the OC File Manager from your computer.
sudo rm /usr/bin/ocfm
sudo rm /usr/share/applications/ocfm.desktop
