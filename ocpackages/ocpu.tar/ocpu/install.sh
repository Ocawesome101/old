#!/bin/bash

cp insts.txt "$HOME"/Desktop/ocpu_insts.txt
cp rom.asm "$HOME"/Desktop/ocpu_rom.asm
cp ocasm /usr/bin/
cp ocpu.py /usr/bin/ocpu
chmod +x /usr/bin/ocpu /usr/bin/ocasm
