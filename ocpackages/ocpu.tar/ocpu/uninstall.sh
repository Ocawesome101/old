#!/bin/bash 

rm /usr/bin/ocpu /usr/bin/ocasm "$HOME"/Desktop/ocpu_insts.txt \
"$HOME"/Desktop/ocpu_rom.asm
